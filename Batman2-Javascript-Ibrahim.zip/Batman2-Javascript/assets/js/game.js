document.addEventListener('DOMContentLoaded', function(){
const btnSuivant = document.getElementById("question-suivante")
btnSuivant.style.display ="none"
let indexQuestion = 0;
let contentQuestion="";
let boxForQuestion = document.getElementById("questions")
const question = [
  {
      "question": "Quel est l’autre nom de l’Homme-Mystère ?",
      "response": [
          {
              "text": "Le Saphinx",
              "isGood": true
          },
          {
              "text": "Le Saphir",
              "isGood": true
          },
          {
              "text": "Le Joker",
              "isGood": true
          }
      ]
  },
  {
      "question": "Quelle est l’ancienne profession de Harley Quinn ?",
      "response": [
          {
              "text": "Infimière",
              "isGood": false
          },
          {
              "text": "Psychiatre",
              "isGood": true
          },
          {
              "text": "Dentiste",
              "isGood": false
          }
      ]
  },
  {
      "question": "Quel est l’objet fétiche de Double Face ?",
      "response": [
          {
              "text": "Une pièce",
              "isGood": true
          },
          {
              "text": "Un livre",
              "isGood": false
          },
          {
              "text": "Un couteau",
              "isGood": false
          }
      ]
  },
  {
      "question": "Quelle ville Batman défend-il ?",
      "response": [
          {
              "text": "Gotham City",
              "isGood": true
          },
          {
              "text": "Starling City",
              "isGood": false
          },
          {
              "text": "Tananarive",
              "isGood": false
          }
      ]
  },
  {
      "question": "Tim Burtin a réalisé deux Batman, qui jouait Batman ?",
      "response": [
          {
              "text": "Georges Clooney",
              "isGood": false
          },
          {
              "text": "Val Kilmer",
              "isGood": false
          },
          {
              "text": "Mickael Keaton",
              "isGood": false
          }
      ]
  },
  {
      "question": "Quel est le prénom des parents du jeune Bruce Wayne ?",
      "response": [
          {
              "text": "Matina et Adam",
              "isGood": false
          },
          {
              "text": "Elaine et Georges",
              "isGood": true
          },
          {
              "text": "Martha et James",
              "isGood": false
          }
      ]
  },
  {
      "question": "Dans son premier Batman (1989) Jack Nicholson jouait :",
      "response": [
          {
              "text": "Le Pingouin",
              "isGood": false
          },
          {
              "text": "L'Homme mystère",
              "isGood": true
          },
          {
              "text": "Le Geek",
              "isGood": false
          }
      ]
  },
  {
      "question": " Qui interprète le Joker en 2008 ?",
      "response": [
          {
              "text": "Heath Legder",
              "isGood": false
          },
          {
              "text": "Haeth Ledger",
              "isGood": false
          },
          {
              "text": "Heath Ledger",
              "isGood": true
          }
      ]
  },
  {
      "question": "En quelle année Robin fait il sa première apparition ?",
      "response": [
          {
              "text": "1940",
              "isGood": true
          },
          {
              "text": "1936",
              "isGood": false
          },
          {
              "text": "1941",
              "isGood": false
          }
      ]
  },
  {
      "question": "Qui est la fille de Batman et Catwoman (Earth - 2) ?",
      "response": [
          {
              "text": "Oracle Huntress",
              "isGood": true
          },
          {
              "text": "Black Canary",
              "isGood": false
          },
          {
              "text": "L'Epouvantail",
              "isGood": false
          }
      ]
  },
  {
      "question": "Batman c’est aussi le nom d’une ville en...",
      "response": [
          {
              "text": "Islande",
              "isGood": false
          },
          {
              "text": "Turquie",
              "isGood": true
          },
          {
              "text": "Allemagne",
              "isGood": false
          }
      ]
  },
  {
      "question": "Qui a realisé Batman en 1966 ?",
      "response": [
          {
              "text": "Stanley Kubrick",
              "isGood": false
          },
          {
              "text": "Andy Warhol",
              "isGood": false
          },
          {
              "text": "Leslie Martinson",
              "isGood": true
          }
      ]
  }
]

  document.getElementById("demarrer").addEventListener("click",function () {
    
    contentQuestion = `<h2 class="nombreDeQuestions">
    <span id="current-question">${indexQuestion+1}</span>/ <span id="total">15</span>
</h2>
<div class="content-quizz">
    <div class="card-quizz">
    <div class="card-image">
        <img src="./assets/Illustrations_game/Batgame_3.png" alt="">
    </div>
    </div>

<div class="card-body-quizz" style="margin-top: 50px;">
    <div class="question-quizz">
    ${question[indexQuestion]['question']}
    </div>
    <div class="choisirReponse" style="margin-top: 20px;">
        <div class="qcm" style="margin-top: 18px;">
            <input type="checkbox" name="quizz${indexQuestion}" class="quizz${indexQuestion}" value="0">
            <label for="">${question[indexQuestion]['response'][0]['text']}</label>
        </div>
        <div class="qcm" style="margin-top: 18px;">
            <input type="checkbox" name="quizz${indexQuestion}" class="quizz${indexQuestion}" value="1">
            <label for="">${question[indexQuestion]['response'][1]['text']}</label>
        </div>
        <div class="qcm" style="margin-top: 18px;">
            <input type="checkbox" name="quizz${indexQuestion}" class="quizz${indexQuestion}" value="2">
            <label for="">${question[indexQuestion]['response'][2]['text']}</label>
        </div>
    </div>
</div>
</div>`;

boxForQuestion.innerHTML= contentQuestion 
btnSuivant.style.display ="inline"
document.getElementById("demarrer").remove()


  })

  // au click du boutton suivant
  document.getElementById("question-suivante").addEventListener("click",function(){

   
if(indexQuestion<12){
  contentQuestion = `<h2 class="nombreDeQuestions">
    <span id="current-question">${indexQuestion+1}</span>/ <span id="total">15</span>
</h2>
<div class="content-quizz">
    <div class="card-quizz">
    <div class="card-image">
        <img src="./assets/Illustrations_game/Batgame_${indexQuestion+3}.png" alt="">
    </div>
    </div>

<div class="card-body-quizz" style="margin-top: 50px;">
    <div class="question-quizz">
    ${question[indexQuestion]['question']}
    </div>
    <div class="choisirReponse" style="margin-top: 20px;">
        <div class="qcm" style="margin-top: 18px;">
            <input type="checkbox" name="quizz${indexQuestion}" class="quizz${indexQuestion}" value="0">
            <label for="">${question[indexQuestion]['response'][0]['text']}</label>
        </div>
        <div class="qcm" style="margin-top: 18px;">
            <input type="checkbox" name="quizz${indexQuestion}" class="quizz${indexQuestion}" value="1">
            <label for="">${question[indexQuestion]['response'][1]['text']}</label>
        </div>
        <div class="qcm" style="margin-top: 18px;">
            <input type="checkbox" name="quizz${indexQuestion}" class="quizz${indexQuestion}" value="2">
            <label for="">${question[indexQuestion]['response'][2]['text']}</label>
        </div>
    </div>
</div>
</div>`;

if(indexQuestion==0){
var Checkbox = document.getElementsByClassName('quizz'+indexQuestion)
console.log(Checkbox[0]);
for (var i=0;i<Checkbox.length;i++){
 if(Checkbox[i].checked){
   var checked = Checkbox[i].value
   console.log(checked);
   break
 }
}
}else{
    var Checkbox = document.getElementsByClassName('quizz'+indexQuestion-1)
console.log(Checkbox[0]);
for (var i=0;i<Checkbox.length;i++){
 if(Checkbox[i].checked){
   var checked = Checkbox[i].value
   console.log(checked);
   break
 }
}
}


boxForQuestion.innerHTML= contentQuestion 


indexQuestion++;

}else{
  boxForQuestion.innerHTML="Vous avez fini toute les questions"
}
    
  })

  })
